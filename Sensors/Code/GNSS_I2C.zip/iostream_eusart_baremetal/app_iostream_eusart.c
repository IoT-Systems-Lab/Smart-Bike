#include <stdio.h>
#include <string.h>
#include "sl_iostream.h"
#include "sl_iostream_init_instances.h"
#include "sl_iostream_handles.h"
#include "sl_i2cspm.h"
#include "sl_i2cspm_instances.h"
#include "sl_sleeptimer.h"

#ifndef BUFSIZE
#define BUFSIZE    80
#endif

#define GNSS_I2C_ADDR   (0x66)
#define REG_LAT_1       0x0E   // 6 bytes voor L76K latitude
#define REG_LON_1       0x14   // 6 bytes voor L76K longitude
#define REG_SAT_USED    0x05   // aantal gebruikte satellieten

static bool gnss_read_bytes(uint8_t reg, uint8_t *data, uint8_t len) {
  I2C_TransferSeq_TypeDef seq;
  uint8_t cmd[1] = { reg };
  seq.addr  = GNSS_I2C_ADDR << 1;
  seq.flags = I2C_FLAG_WRITE_READ;
  seq.buf[0].data = cmd;
  seq.buf[0].len  = 1;
  seq.buf[1].data = data;
  seq.buf[1].len  = len;
  I2C_TransferReturn_TypeDef ret = I2CSPM_Transfer(sl_i2cspm_mikroe, &seq); // pas instance aan als nodig!
  return ret == i2cTransferDone;
}

void app_iostream_eusart_init(void)
{
    #if !defined(__CROSSWORKS_ARM) && defined(__GNUC__)
      setvbuf(stdout, NULL, _IONBF, 0);
      setvbuf(stdin, NULL, _IONBF, 0);
    #endif

    sl_i2cspm_init_instances();
    sl_sleeptimer_init();
    sl_iostream_init_instances_stage_1();
    sl_iostream_init_instances_stage_2();

    const char str1[] = "Start DFRobot GNSS via I2C...\r\n";
    sl_iostream_write(sl_iostream_vcom_handle, str1, strlen(str1));
    sl_iostream_set_default(sl_iostream_recommended_console_stream);
    printf("Nu gebruikt printf de juiste VCOM!\r\n");
}

void app_iostream_eusart_process_action(void)
{
  static uint32_t last_tick = 0;
  if (sl_sleeptimer_get_tick_count() - last_tick > 10000)
  {
    last_tick = sl_sleeptimer_get_tick_count();

    // Latitude
    uint8_t lat_raw[6] = {0};
    if (gnss_read_bytes(REG_LAT_1, lat_raw, 6)) {
      uint8_t lat_dd = lat_raw[0];
      uint8_t lat_mm = lat_raw[1];
      uint32_t lat_mmmmm = ((uint32_t)lat_raw[2] << 16) | ((uint32_t)lat_raw[3] << 8) | lat_raw[4];
      char lat_dir = (char)lat_raw[5];

      // Debug: print bufferinhoud
      printf("RAW lat: %02X %02X %02X %02X %02X [%c]\n",
        lat_raw[0], lat_raw[1], lat_raw[2], lat_raw[3], lat_raw[4], lat_dir);

      double latitude_deg = lat_dd + lat_mm / 60.0 + lat_mmmmm / 100000.0 / 60.0;
      printf("Latitude: %.7f° %c\n", latitude_deg, lat_dir);
    } else {
      printf("Kan latitude niet uitlezen via I2C!\n");
    }

    // Longitude
    uint8_t lon_raw[6] = {0};
    if (gnss_read_bytes(REG_LON_1, lon_raw, 6)) {
      uint8_t lon_ddd = lon_raw[0];
      uint8_t lon_mm = lon_raw[1];
      uint32_t lon_mmmmm = ((uint32_t)lon_raw[2] << 16) | ((uint32_t)lon_raw[3] << 8) | lon_raw[4];
      char lon_dir = (char)lon_raw[5];

      // Debug: print bufferinhoud
      printf("RAW lon: %02X %02X %02X %02X %02X [%c]\n",
        lon_raw[0], lon_raw[1], lon_raw[2], lon_raw[3], lon_raw[4], lon_dir);

      double longitude_deg = lon_ddd + lon_mm / 60.0 + lon_mmmmm / 100000.0 / 60.0;
      printf("Longitude: %.7f° %c\n", longitude_deg, lon_dir);
    } else {
      printf("Kan longitude niet uitlezen via I2C!\n");
    }

    // Satellieten
    uint8_t nSat = 0;
    if (gnss_read_bytes(REG_SAT_USED, &nSat, 1)) {
      printf("Satellieten gebruikt: %d\n", nSat);
    } else {
      printf("Kan satellieten-info niet uitlezen via I2C!\n");
    }

    printf("==============================\n");
  }
}
