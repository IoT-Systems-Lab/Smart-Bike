#ifndef APP_IOSTREAM_EUSART_H
#define APP_IOSTREAM_EUSART_H

void app_iostream_eusart_init(void);

void app_iostream_eusart_process_action(void);

#endif  // APP_IOSTREAM_EUSART_H
