/***************************************************************************//**
 * @file
 * @brief Core application logic - BLE Coded PHY + GNSS I2C Satellite Data
 *******************************************************************************
 * # License
 * <b>Copyright 2024 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * SPDX-License-Identifier: Zlib
 *
 * The licensor of this software is Silicon Laboratories Inc.
 *
 * This software is provided 'as-is', without any express or implied
 * warranty. In no event will the authors be held liable for any damages
 * arising from the use of this software.
 *
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, and to alter it and redistribute it
 * freely, subject to the following restrictions:
 *
 * 1. The origin of this software must not be misrepresented; you must not
 *    claim that you wrote the original software. If you use this software
 *    in a product, an acknowledgment in the product documentation would be
 *    appreciated but is not required.
 * 2. Altered source versions must be plainly marked as such, and must not be
 *    misrepresented as being the original software.
 * 3. This notice may not be removed or altered from any source distribution.
 *
 ******************************************************************************/
#include "sl_bt_api.h"
#include "sl_main_init.h"
#include "app_assert.h"
#include "app.h"
#include "gatt_db.h"
#include "app_log.h"
#include "sl_i2cspm.h"
#include "sl_i2cspm_instances.h"
#include "sl_sleeptimer.h"
#include <string.h>


// GNSS Configuration (DFRobot L76K)
#define GNSS_I2C_ADDR   0x66
#define REG_LAT_1       0x0E   // 6 bytes latitude
#define REG_LON_1       0x14   // 6 bytes longitude
#define REG_SAT_USED    0x05   // 1 byte: aantal satellieten

// The advertising set handle allocated from Bluetooth stack.
static uint8_t advertising_set_handle = 0xff;

// BLE Connection handle and PHY state
static uint8_t ble_connection_handle = 0xFF;
static uint8_t ble_coded_phy_active = 0;

// Timing for periodic GNSS reads
static uint32_t last_gnss_tick = 0;
#define GNSS_READ_INTERVAL_MS 1000  // Read GNSS every 10 seconds


// GNSS I2C Helper Functions


/**
 * Read bytes from GNSS module via I2C
 */
static bool gnss_read_bytes(uint8_t reg, uint8_t *data, uint8_t len)
{
  I2C_TransferSeq_TypeDef seq;
  uint8_t cmd[1] = { reg };

  seq.addr  = GNSS_I2C_ADDR << 1;
  seq.flags = I2C_FLAG_WRITE_READ;
  seq.buf[0].data = cmd;
  seq.buf[0].len  = 1;
  seq.buf[1].data = data;
  seq.buf[1].len  = len;

  I2C_TransferReturn_TypeDef ret = I2CSPM_Transfer(sl_i2cspm_mikroe, &seq);
  return ret == i2cTransferDone;
}

/**
 * Read RAW latitude data (6 bytes)
 */
static bool gnss_read_latitude(uint8_t *lat_raw)
{
  return gnss_read_bytes(REG_LAT_1, lat_raw, 6);
}

/**
 * Read RAW longitude data (6 bytes)
 */
static bool gnss_read_longitude(uint8_t *lon_raw)
{
  return gnss_read_bytes(REG_LON_1, lon_raw, 6);
}

/**
 * Read number of satellites used
 */
static bool gnss_read_satellites(uint8_t *nsat)
{
  return gnss_read_bytes(REG_SAT_USED, nsat, 1);
}


// SEND DATA via BLE NOTIFY (Coded PHY)

void send_satellite_data(uint8_t *data, uint16_t length)
{
  sl_status_t sc;

  if (ble_connection_handle == 0xFF) {
    app_log_warning("Not connected - cannot send data\r\n");
    return;
  }

  if (length > 244) {
    app_log_error("Data too large! Max 244 bytes (got %d)\r\n", length);
    return;
  }

  sc = sl_bt_gatt_server_send_notification(
    ble_connection_handle,
    gattdb_satellite_data,
    length,
    data
  );

  if (sc == SL_STATUS_OK) {
    app_log_info("Sent %d bytes via %s PHY\r\n",
                 length,
                 ble_coded_phy_active ? "Coded" : "1M");
  } else {
    app_log_error("Notify failed: 0x%04x\r\n", sc);
  }
}


// SEND RAW GNSS DATA via BLE
// Format: [LAT_RAW:6][LON_RAW:6][NSAT:1] = 13 bytes

void send_gnss_raw_data(void)
{
  uint8_t payload[13];  // 6 + 6 + 1 = 13 bytes
  uint8_t lat_raw[6] = {0};
  uint8_t lon_raw[6] = {0};
  uint8_t nsat = 0;
  bool gnss_valid = true;

  // Read latitude
  if (!gnss_read_latitude(lat_raw)) {
    app_log_warning("Failed to read latitude - sending zeros\r\n");
    memset(lat_raw, 0, 6);
    gnss_valid = false;
  }

  // Read longitude
  if (!gnss_read_longitude(lon_raw)) {
    app_log_warning("Failed to read longitude - sending zeros\r\n");
    memset(lon_raw, 0, 6);
    gnss_valid = false;
  }

  // Read satellites
  if (!gnss_read_satellites(&nsat)) {
    app_log_warning("Failed to read satellites - sending zeros\r\n");
    nsat = 0;
    gnss_valid = false;
  }

  // Build payload: [LAT:6][LON:6][NSAT:1]
  memcpy(&payload[0], lat_raw, 6);
  memcpy(&payload[6], lon_raw, 6);
  payload[12] = nsat;

  // Log raw data for debugging
  if (gnss_valid) {
    app_log_info("RAW GNSS: LAT[%02X %02X %02X %02X %02X %c] LON[%02X %02X %02X %02X %02X %c] SAT=%d\r\n",
      lat_raw[0], lat_raw[1], lat_raw[2], lat_raw[3], lat_raw[4], lat_raw[5],
      lon_raw[0], lon_raw[1], lon_raw[2], lon_raw[3], lon_raw[4], lon_raw[5],
      nsat);
  } else {
    app_log_warning("GNSS NO SIGNAL - sending zeros\r\n");
  }

  // Send via BLE (always send, even if zeros)
  send_satellite_data(payload, 13);
}

// SEND ARBITRARY BINARY DATA

void send_binary_data(const uint8_t *data, uint16_t length)
{
  send_satellite_data((uint8_t *)data, length);
}

// Application Init.
void app_init(void)
{
  /////////////////////////////////////////////////////////////////////////////
  // Put your additional application init code here!                         //
  // This is called once during start-up.                                    //
  /////////////////////////////////////////////////////////////////////////////

  // Initialize I2C for GNSS
  sl_i2cspm_init_instances();
  sl_sleeptimer_init();

  app_log_info("GNSS I2C Initialized\r\n");
}

// Application Process Action.
void app_process_action(void)
{
  if (app_is_process_required()) {
    /////////////////////////////////////////////////////////////////////////////
    // Put your additional application code here!                              //
    // This is will run each time app_proceed() is called.                     //
    // Do not call blocking functions from here!                               //
    /////////////////////////////////////////////////////////////////////////////

    // Periodically read and send GNSS data (every 10 seconds)
    uint32_t current_tick = sl_sleeptimer_get_tick_count();
    if (current_tick - last_gnss_tick > (GNSS_READ_INTERVAL_MS / 10)) {  // sleeptimer is 10ms per tick
      last_gnss_tick = current_tick;

      if (ble_connection_handle != 0xFF) {
        app_log_info("Reading GNSS data...\r\n");
        send_gnss_raw_data();
      }
    }
  }
}

/**************************************************************************//**
 * Bluetooth stack event handler.
 * This overrides the default weak implementation.
 *
 * @param[in] evt Event coming from the Bluetooth stack.
 *****************************************************************************/
void sl_bt_on_event(sl_bt_msg_t *evt)
{
  sl_status_t sc;

  switch (SL_BT_MSG_ID(evt->header)) {

    // ======================================
    // SYSTEM BOOT
    // ======================================
    case sl_bt_evt_system_boot_id:
      app_log_info("BLE Boot - MGM260P Ready!\r\n");

      // Create an advertising set.
      sc = sl_bt_advertiser_create_set(&advertising_set_handle);
      app_assert_status(sc);

      // Generate data for advertising
      sc = sl_bt_legacy_advertiser_generate_data(advertising_set_handle,
                                                 sl_bt_advertiser_general_discoverable);
      app_assert_status(sc);

      // Set advertising interval to 100ms.
      sc = sl_bt_advertiser_set_timing(
        advertising_set_handle,
        160, // min. adv. interval (milliseconds * 1.6)
        160, // max. adv. interval (milliseconds * 1.6)
        0,   // adv. duration
        0);  // max. num. adv. events
      app_assert_status(sc);

      // Start advertising and enable connections.
      sc = sl_bt_legacy_advertiser_start(advertising_set_handle,
                                         sl_bt_legacy_advertiser_connectable);
      app_assert_status(sc);
      app_log_info("Advertising started\r\n");
      break;


    // CONNECTION OPENED

    case sl_bt_evt_connection_opened_id:
      ble_connection_handle = evt->data.evt_connection_opened.connection;
      ble_coded_phy_active = 0;

      app_log_info("BLE Connected! Connection handle: %d\r\n",
                   ble_connection_handle);

      app_proceed();
      // REQUEST CODED PHY (Long Range - 125 kbps)
      sc = sl_bt_connection_set_preferred_phy(
        ble_connection_handle,
        0,                          // all_phys: 0 = auto-negotiate
        sl_bt_gap_phy_coded        // preferred_phy: REQUEST CODED PHY
      );

      app_log_info("Requesting Coded PHY: 0x%04x\r\n", sc);
      break;


    // CONNECTION CLOSED

    case sl_bt_evt_connection_closed_id:
      ble_connection_handle = 0xFF;
      ble_coded_phy_active = 0;

      app_log_info("BLE Disconnected\r\n");

      // Generate data for advertising
      sc = sl_bt_legacy_advertiser_generate_data(advertising_set_handle,
                                                 sl_bt_advertiser_general_discoverable);
      app_assert_status(sc);

      // Restart advertising after client has disconnected.
      sc = sl_bt_legacy_advertiser_start(advertising_set_handle,
                                         sl_bt_legacy_advertiser_connectable);
      app_assert_status(sc);
      app_log_info("Advertising restarted\r\n");
      break;


    // PHY UPDATE STATUS

    case sl_bt_evt_connection_phy_status_id:
    {
      uint8_t phy = evt->data.evt_connection_phy_status.phy;

      if (phy == sl_bt_gap_phy_coded) {
        app_log_info("CODED PHY ACTIVE (125 kbps Long Range)\r\n");
        ble_coded_phy_active = 1;
      } else if (phy == sl_bt_gap_phy_1m) {
        app_log_info("1M PHY active (1 Mbps)\r\n");
        ble_coded_phy_active = 0;
      } else if (phy == sl_bt_gap_phy_2m) {
        app_log_info("2M PHY active (2 Mbps)\r\n");
        ble_coded_phy_active = 0;
      }
      break;
    }


    // GATT SERVER CHARACTERISTIC STATUS

    case sl_bt_evt_gatt_server_characteristic_status_id:
      if (evt->data.evt_gatt_server_characteristic_status.characteristic
          == gattdb_satellite_data) {

        uint16_t status_flags = evt->data.evt_gatt_server_characteristic_status.status_flags;

        if (status_flags & 0x01) {  // Client enabled notifications
          app_log_info("Client ENABLED notifications on satellite_data\r\n");
        } else {
          app_log_info("Client DISABLED notifications\r\n");
        }
      }
      break;


    // Add additional event handlers here as your application requires!      //



    // Default event handler.

    default:
      break;
  }
}
